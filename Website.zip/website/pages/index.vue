<template>
  <div>
    <div class="container">
      <div class="main">
        <div class="main-title">
          <h1>
            kappug
            <v-icon>mdi-airplane</v-icon>
          </h1>
          <p>
            backend developer, dabbling in frontend for projects
          </p>
        </div>
        <div class="main-buttons">
          <v-btn color="#5865F2" href="https://discord.com/users/715541337549570114">
            <v-icon>
              mdi-discord
            </v-icon>
            Discord
          </v-btn>
          <v-btn href="https://github.com/Kappug">
            <v-icon>
              mdi-github
            </v-icon>
            GitHub
          </v-btn>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.main {
  top: 45%;
  margin-left: 8vw;
  margin-right: 8vw;
  transform: translateY(-50%);
  position: fixed;
}

.v-icon {
  margin-right: 6px;
}
</style>